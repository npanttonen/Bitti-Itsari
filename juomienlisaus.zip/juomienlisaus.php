<?php
$juoma = isset($_POST["juoma"]) ? $_POST["juoma"] : "";
mysqli_report(MYSQLI_REPORT_ALL ^ MYSQLI_REPORT_INDEX);

try{
   $yhteys=mysqli_connect("db", "root", "password", "henkilokanta");
}
catch(Exception $e){
    header("Location:../html/yhteysvirhe.html");
    exit;
}

if (!empty($juoma)) {
    //Tehdään sql-lause, jossa kysymysmerkeillä osoitetaan paikat
    //joihin laitetaan muuttujien arvoja
    $sql = "insert into juoma (nimi) values(?)";

    //Valmistellaan sql-lause
    $stmt = mysqli_prepare($yhteys, $sql);
    //Sijoitetaan muuttujat oikeisiin paikkoihin
    mysqli_stmt_bind_param($stmt, 's', $juoma);
    //Suoritetaan sql-lause
    mysqli_stmt_execute($stmt);
    $last_id = mysqli_insert_id($yhteys);
    
    header("location:juomienlisaus.php");
    exit;
}
print "<a href='henkilolomake.php'>Lomakeeseen </a>";
print "<a href='tallennahenkilo.php'>henkilot</a>";
//tulostus
$tulos=mysqli_query($yhteys, "select * from juoma");
print "<table border='1'>";
while ($rivi=mysqli_fetch_object($tulos)){
    print "<tr><td><p>$rivi->id<td>$rivi->nimi<td><a href='poistajuoma.php?poistettava=$rivi->id'>Poista</a></p>".
    "<td><p><a href='./muokkaajuoma.php?muokattava=$rivi->id'>Muokkaa</a></p></tr>";
}
print "</table>";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lisää henkilö</title>
</head>
<body>
    <form action="juomienlisaus.php" method="post">
        <input type="text" name="juoma" value=""><br> 
        <input type="submit" name="ok" value="OK"><br>
    </form>
</body>
</html>
<?php mysqli_close($yhteys) ?>